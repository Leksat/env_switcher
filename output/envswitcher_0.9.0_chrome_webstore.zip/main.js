﻿kango.ui.browserButton.setTooltipText('');
kango.ui.browserButton.setPopup({url: 'popup.html', width: 300, height: 300});
